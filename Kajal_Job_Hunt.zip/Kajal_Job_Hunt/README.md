# Welcome to Job Hunt.!

**Job Hunt** is Job Portal web application project, built using ReactJS.
- use `localstorage` to save information in brower.
- use api for **Feature Job** section
- Added **Job category** list.

User can see the job details from feature job section and apply for the preferred job. After that all applied job are shown on **Applied Jobs** section. 

### Live site Link: [Job Hunt](https://job-hero.netlify.app/)
